function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let farmer;

let fruits = [];

let score = 0;

let missed = 0;

let gameOver = false;

function setup() {

  createCanvas(600, 400);

  farmer = new Farmer();

  textFont('Georgia');

}

function draw() {

  background(135, 206, 235); // céu

  drawGround();

  if (!gameOver) {

    farmer.move();

    farmer.show();

    if (random(1) < 0.02) {

      fruits.push(new Fruit());

    }

    for (let i = fruits.length - 1; i >= 0; i--) {

      fruits[i].fall();

      fruits[i].show();

      if (fruits[i].hits(farmer)) {

        score++;

        fruits.splice(i, 1);

      } else if (fruits[i].y > height) {

        missed++;

        fruits.splice(i, 1);

      }

    }

    fill(0);

    textSize(18);

    text("Pontos: " + score, 10, 20);

    text("Frutas perdidas: " + missed, 10, 40);

    if (missed >= 5) {

      gameOver = true;

    }

  } else {

    fill(0);

    textSize(32);

    textAlign(CENTER);

    text("Fim de jogo!", width / 2, height / 2);

    text("Pontuação final: " + score, width / 2, height / 2 + 40);

  }

}

function drawGround() {

  fill(34, 139, 34);

  rect(0, 350, width, 50);

}

class Farmer {

  constructor() {

    this.x = width / 2;

    this.size = 50;

  }

  move() {

    if (keyIsDown(LEFT_ARROW)) {

      this.x -= 5;

    }

    if (keyIsDown(RIGHT_ARROW)) {

      this.x += 5;

    }

    this.x = constrain(this.x, 0, width - this.size);

  }

  show() {

    push();

    translate(this.x + this.size / 2, 320);

    // Corpo

    fill(0, 100, 255);

    rect(-15, 0, 30, 40); // camisa

    fill(139, 69, 19);

    rect(-15, 30, 30, 20); // calça

    // Cabeça

    fill(255, 220, 177);

    ellipse(0, -20, 25, 25);

    // Chapéu

    fill(194, 178, 128);

    ellipse(0, -28, 30, 8);

    rect(-10, -40, 20, 12);

    // Braços

    stroke(255, 220, 177);

    strokeWeight(4);

    line(-15, 10, -25, 20); // braço esquerdo

    line(15, 10, 25, 20);   // braço direito

    pop();

  }

}

class Fruit {

  constructor() {

    this.x = random(width);

    this.y = 0;

    this.size = 20;

    this.speed = random(2, 4);

  }

  fall() {

    this.y += this.speed;

  }

  show() {

    fill(255, 0, 0);

    ellipse(this.x, this.y, this.size);

  }

  hits(farmer) {

    return (

      this.y + this.size > 320 &&

      this.x > farmer.x &&

      this.x < farmer.x + farmer.size

    );

  }

}